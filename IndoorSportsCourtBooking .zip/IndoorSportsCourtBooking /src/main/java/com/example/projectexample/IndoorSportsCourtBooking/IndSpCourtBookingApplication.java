package com.example.projectexample.IndoorSportsCourtBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndSpCourtBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndSpCourtBookingApplication.class, args);
	}

}
