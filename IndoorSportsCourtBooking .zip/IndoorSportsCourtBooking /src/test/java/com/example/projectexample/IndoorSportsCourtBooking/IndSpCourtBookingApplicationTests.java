package com.example.projectexample.IndoorSportsCourtBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndSpCourtBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
